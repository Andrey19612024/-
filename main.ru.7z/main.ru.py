print(12+89-1)
# "1st program"
print(9**0.5*5)
# "2nd program"
print(9.99>9.98 and 1000!=1000.1)
# "3rd program"
print(1234%1000//10)
print(5678%1000//10)
print(23+67)
# "4rd program"
print(int(13.42))
print(int(42.13))
print(13.42*100%100)
print(42.13*100%100)
print(13==13 or 42==42)